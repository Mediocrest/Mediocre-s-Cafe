<!DOCTYPE html>
<html>
    <body>

    <?php ?>

    <form action="" method="get">
        Name: <input type="text" name="name">
        <input type="submit">
    </form>

    </body>
</html>